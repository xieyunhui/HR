create TYPE acObj as OBJECT
(
    ID number(5),
    transferor number(5),
    receiver number(5),
    money number(16,2)
)
/

