create procedure TEST_PRO(vi_transfer_id in number,
                                     vi_receiver_id in number,
                                     vi_amount in number,
                                     vo_status_code out number)
    is
    v_transfer_bankCard USERS.BANKCARD%type;
    v_receiver_bankCard USERS.BANKCARD%type;
    v_balance           USERS.BALANCE%type;
    v_chek_user         number(2) := 0;
begin
    --------------
    --准备工作
    --双方卡号是否存在
    select bankCard into v_transfer_bankCard from USERS where ID = vi_transfer_id;
    select bankCard into v_receiver_bankCard from USERS where ID = vi_receiver_id;

    if (v_transfer_bankCard is null) then
        vo_status_code := 1;
        return;
    end if;

    if (v_receiver_bankCard is null) then
        vo_status_code := 2;
        return;
    end if;

    --转账金额是否正常
    select BALANCE into v_balance from USERS where ID = vi_transfer_id;
    if (v_balance < vi_amount) then
        vo_status_code := 3;
        return;
    end if;

    --是否存在双方用户
    --查询转账人
    select count(ID) into v_chek_user from USERS where ID = vi_transfer_id;

    if (v_chek_user <= 0) then
        vo_status_code := 5;
        return;
    end if;

    --查询收款人
    select count(ID) into v_chek_user from USERS where ID = vi_receiver_id;
    if (v_chek_user <= 0) then
        vo_status_code := 6;
        return;
    end if;

    --用户是否存在风险
    --todo 用户风险

    --准备结束
    --------------
    --------------
    --开始转账
    --减去转账金额
    update USERS set BALANCE=BALANCE - vi_amount where ID = vi_transfer_id;

    --增加转账金额
    update USERS set BALANCE=BALANCE + vi_amount where ID = vi_receiver_id;

    --插入一条转账记录
    insert into ACCOUNT(id, transferor, receiver, money)
    VALUES (AUTOID.nextval, vi_transfer_id, vi_receiver_id, vi_amount);
    --结束转账
    --------------

    commit;
    vo_status_code := 0;

    --执行结束
    DBMS_OUTPUT.PUT_LINE('执行成功！');
EXCEPTION
    when NO_DATA_FOUND then
        vo_status_code := 7;
        rollback;
end;
/

