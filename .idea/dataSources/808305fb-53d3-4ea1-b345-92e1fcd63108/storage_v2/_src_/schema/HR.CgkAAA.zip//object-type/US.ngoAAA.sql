create TYPE us as OBJECT
(
    id number,
    username varchar2(200),
    bankcard varchar2(200),
    balance number(16,2)
)
/

